--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: corpus; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE corpus IS 'Base del corpus';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: expresiones_referenciales_id_expresion_referencial_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE expresiones_referenciales_id_expresion_referencial_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.expresiones_referenciales_id_expresion_referencial_seq OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: expresiones_referenciales; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE expresiones_referenciales (
    id_persona integer NOT NULL,
    id_mapa character varying NOT NULL,
    expresion_referencial character varying NOT NULL,
    id_expresion_referencial integer DEFAULT nextval('expresiones_referenciales_id_expresion_referencial_seq'::regclass) NOT NULL
);


ALTER TABLE public.expresiones_referenciales OWNER TO postgres;

--
-- Name: personas_id_persona_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE personas_id_persona_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.personas_id_persona_seq OWNER TO postgres;

SET default_with_oids = true;

--
-- Name: personas; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE personas (
    id_persona integer DEFAULT nextval('personas_id_persona_seq'::regclass),
    edad integer NOT NULL,
    sexo integer NOT NULL,
    idioma character varying NOT NULL,
    que_estudia character varying NOT NULL,
    nacionalidad character varying NOT NULL,
    identificacion character varying,
    fecha_hora_inicio timestamp with time zone,
    fecha_hora_fin timestamp with time zone
);


ALTER TABLE public.personas OWNER TO postgres;

--
-- Data for Name: expresiones_referenciales; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY expresiones_referenciales (id_persona, id_mapa, expresion_referencial, id_expresion_referencial) FROM stdin;
\.


--
-- Name: expresiones_referenciales_id_expresion_referencial_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('expresiones_referenciales_id_expresion_referencial_seq', 1, false);


--
-- Data for Name: personas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY personas (id_persona, edad, sexo, idioma, que_estudia, nacionalidad, identificacion, fecha_hora_inicio, fecha_hora_fin) FROM stdin;
\.


--
-- Name: personas_id_persona_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('personas_id_persona_seq', 1, false);


--
-- Name: personas_persona_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY personas
    ADD CONSTRAINT personas_persona_id_key UNIQUE (id_persona);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

